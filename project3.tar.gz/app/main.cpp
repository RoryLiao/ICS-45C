#include "HashMap.hpp"
#include<iostream>
#include<sstream>
int main()
{   
    HashMap map;
    std::string full_input;
    std::string input;
    std::string username;
    std::string password;
    int debug = 0;
    while (true)
    {
        username = "";
        password = "";
        getline(std::cin, full_input);
        std::istringstream in(full_input);
        in >> input;
        in >> username;
        in >> password;
        if (input == "CREATE")
        {   
            if (map.contains(username) == false)
            {    
                map.add(username, password);
                std::cout << "CREATED" << std::endl;
            }
            else
            {
                std::cout << "EXISTS" << std::endl;
            }
        }
	    else if (input == "LOGIN" && username == "COUNT" && debug == 1)
        {
            std::cout << map.size() << std::endl;
        }
        else if (input == "LOGIN" && username == "COUNT" && debug == 0)
        {
            std::cout << "INVALID" << std::endl;
        }
        else if (input == "LOGIN")
        {
            if (map.contains(username) && map.value(username) == password)
            {
                std::cout << "SUCCEEDED" << std::endl;
            }
            else 
            {
                std::cout << "FAILED" << std::endl;
            }
        }
        else if (input == "REMOVE")
        {
            if (map.contains(username))
            {
                map.remove(username);
                std::cout << "REMOVED" << std::endl;
            }
            else
            {
                std::cout << "NONEXISTENT" << std::endl;
            }
        }
        else if (input == "CLEAR")
        {
            map.~HashMap();
            std::cout << "CLEARED" << std::endl;
        }
        else if (input == "QUIT")
        {
            std::cout << "GOODBYE" << std::endl;
            break;
        }
        else if (input == "DEBUG" && username == "ON")
        {   if (debug == 0)
            {
                debug = 1;
                std::cout << "ON NOW" << std::endl;
            }
            else if (debug == 1)
            {
                std::cout << "ON ALREADY" << std::endl;
            }
        }
        else if (input == "DEBUG" && username == "OFF")
        {   if (debug == 1)
            {
                debug = 0;
                std::cout << "OFF NOW" << std::endl;
            }
            else if (debug == 0)
            {
                std::cout << "OFF ALREADY" << std::endl;
            }

        }
        
        else if (input == "BUCKET" && username == "COUNT" && debug == 1)
        {
           std::cout << map.bucketCount() << std::endl;
        }
        else if (input == "LOAD" && username == "FACTOR" && debug == 1)
        {
            std::cout << map.loadFactor() << std::endl;
        }
        else if (input == "MAX" && username == "BUCKET" && password ==  "SIZE" && debug == 1)
        {
            std::cout << map.maxBucketSize() << std::endl;
        }
        else
        {
            std::cout << "INVALID" << std::endl;
        }
    }
    return 0;
}

