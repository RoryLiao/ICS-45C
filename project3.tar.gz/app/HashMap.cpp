#include "HashMap.hpp"
#include<iostream>

int hash(const std::string& str)
{
    const char* s = str.c_str();
    unsigned int hash = 0;
    while(*s)
    {
        hash = hash * 101 + *s++;
    }
    return hash;
}
   
HashMap::HashMap()
    :hasher(hash)
{   
    sz = 0;
    Buckets = initialBucketCount;
    table = new Node*[Buckets];
    for (int i = 0; i < Buckets; i++)
    {
        table[i] = NULL;
    }
}

HashMap::HashMap(HashFunction hasher)
    :hasher(hasher)
{
    sz = 0;
    Buckets = initialBucketCount;
    table = new Node*[Buckets];
    for (int i = 0; i < Buckets; i++)
    {
        table[i] = NULL;
    }
}

HashMap::HashMap(const HashMap& hm)
{
    hasher = hm.hasher;
    Buckets = hm.Buckets;
    sz = hm.size();
    table = new Node*[Buckets];
    for (int i=0; i < Buckets; i++)
    {   
        Node* entry = hm.table[i];
        if (entry == NULL)
        {
            table[i] = NULL;
        }
        else
        {
            Node* conductor = entry->next;
            Node* copyer = new Node;
            while (conductor != NULL)
            {
                copyer->key = entry->key;
                copyer->value = entry->value;
                copyer->next = new Node;
                copyer = copyer->next;
                entry = conductor;
                conductor = conductor->next;
                
            }
            copyer->key = entry->key;
            copyer->value = entry->value;
            copyer->next = NULL;
            table[i] = copyer;
            delete copyer;
        }

    }
}

HashMap::~HashMap()
{
    for (int i = 0; i < Buckets; i++)
    {
        Node* entry = table[i];
        while (entry != NULL)
        {   
            Node* prev = entry;
            entry = entry->next;
            delete prev;
        }
        table[i] = NULL;

    }
    sz = 0;
    delete[] table;
}

HashMap& HashMap::operator=(const HashMap& hm)
{
    if (this != &hm)
    {   
        HashMap::~HashMap();
       
        hasher = hm.hasher;
        Buckets = hm.Buckets;
        table = new Node* [Buckets];
        sz = hm.size();

        for (int i=0; i < Buckets; i++)
        {
            Node* entry = hm.table[i];
            if (entry == NULL)
            {
                table[i] = NULL;
            }
            else
            {
                Node* conductor = entry->next;
                Node* copyer = new Node;
                while (conductor != NULL)
                {
                    copyer->key = entry->key;
                    copyer->value = entry->value;
                    copyer->next = new Node;
                    copyer = copyer->next;
                    entry = conductor;
                    conductor = conductor->next;
                }
                copyer->key = entry->key;
                copyer->value = entry->value;
                copyer->next = NULL;
                table[i] = copyer;
            }
        }
    }

    return *this;
}

void HashMap::add(const std::string& key, const std::string& value)
{   
    if (HashMap::contains(key))
    {
        return;
    }
    else
    {
        int index = hasher(key) % Buckets;
        sz++;
        Node* entry = new Node;
        entry->key = key;
        entry->value = value;
        entry->next = table[index];
        table[index] = entry;
        
        
        if (HashMap::loadFactor() > 0.8)
        {   
            int new_size = Buckets * 2 + 1;
            Node** new_table = new Node*[new_size];
            for (int i=0; i < Buckets; i++)
            {
                Node* entry = table[i];
                if (entry == NULL)
                {   
                    continue;
                }
                else
                {
                    int new_index = hasher(entry->key) % new_size;
                    Node* conductor = entry->next;
                    Node* copyer = new Node;
                    while (conductor != NULL)
                    {  
                        copyer->key = entry->key;
                        copyer->value = entry->value;
                        copyer->next = new_table[new_index];
                        new_table[new_index] = copyer;
                        delete entry;
                        entry = conductor;
                        conductor = conductor->next;
                    }
                    copyer->key = entry->key;
                    copyer->value = entry->value;
                    copyer->next = new_table[new_index];
                    new_table[new_index] = copyer;
                    delete entry;
                }
            }
            delete[] table;
            table = new_table;
            Buckets = new_size;
        } 
    }
}

void HashMap::remove(const std::string& key)
{
    int index = hasher(key) % Buckets;
    Node* entry = table[index]; 
    if (entry == NULL)
    {
        return;
    }
    else if (entry->key == key)
    {   
        sz--;
        delete entry;
        table[index] = table[index]->next;
       
    }
    else
    {   
        Node* conductor = table[index]->next;
        while (conductor != NULL)
        {   
            if (conductor->key == key)
            {   
                delete conductor;
                delete entry->next;
                sz--;
                conductor = conductor->next;
                entry->next = conductor;
            }
            else
            {
                entry = conductor;
                conductor = conductor->next;
            }
        }
    }
}

bool HashMap::contains(const std::string& key) const
{
    int index = hasher(key) % Buckets;
    Node* entry = table[index];
    while (entry != NULL)
    {
        if (entry->key == key)
        {
            return true;
        }
        else
        {
            entry = entry->next;
        }
   }
    return false;
}

std::string HashMap::value(const std::string& key) const
{
    int index = hasher(key) % Buckets;
    Node* entry = table[index];
    while (entry != NULL)
    {
        if (entry->key == key)
        {
            return entry->value;
        }
        else
        {
            entry = entry->next;
        }
    }
    return "";
}

unsigned int HashMap::size() const
{
    return sz;
}

unsigned int HashMap::bucketCount() const
{
    return Buckets;
}

double HashMap::loadFactor() const
{
    return double(sz)/Buckets;
}

unsigned int HashMap::maxBucketSize() const
{
    int bucketsize = 0;
    int largestbucket = 0;
    //int i;
    int tracker = 0;
    for (int i=0; i < Buckets; i++)
    {
        Node* entry = table[i];
        while (entry!=NULL)
        {
            bucketsize++;
            entry = entry->next;
            tracker++;
            if (tracker < largestbucket)
            {
                largestbucket = bucketsize;
                tracker = 0;
                bucketsize = 0;
            }
        }
    }
    return largestbucket;
}   
