// HashMapTests.cpp
//
// ICS 45C Fall 2014
// Project #3: Maps and Legends
//
// Write unit tests for your HashMap class here.  I've provided one test already,
// though I've commented it out, because it won't compile until you've implemented
// three things: the HashMap constructor, the HashMap destructor, and HashMap's
// size() member function.

#include <gtest/gtest.h>
#include "HashMap.hpp"


TEST(TestHashMap, sizeOfNewlyCreatedHashMapIsZero)
{
    HashMap empty;
    ASSERT_EQ(0, empty.size());
}

TEST (TestHashMap, canAddContainRemove)
{
	HashMap map;
	map.add("a", "123");
	map.contains("a");
	map.remove("a");
}

TEST (TestHashMap, canCopyStuff)
{
	HashMap map;
	HashMap map2;
	map.add("a", "123");
	map.contains("a");
	map2 = map;
	map2.contains("a");
}
TEST (TestHashMap, canRehash)
{
	HashMap map;
	map.add("a", "123");
	map.add("b", "123");
	map.add("c", "123");
	map.add("d", "123");
	map.add("e", "123");
	map.add("f", "123");
	map.add("g", "123");
	map.add("h", "123");
	map.add("i", "123");
	map.add("j", "123");
	map.contains("a");
	map.contains("b");
	map.contains("c");
	map.contains("d");
	map.contains("e");
	map.contains("f");
	map.contains("g");
	map.contains("h");
	map.contains("i");
	map.contains("j");
}
