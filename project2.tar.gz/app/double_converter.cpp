#include<iostream>
#include "double_converter.hpp"

void double_converter(double* a, int size)
{   
    int i;
    for (i = 0; i < size; i++)
    {
        std::cin >> a[i];
 
    }
}