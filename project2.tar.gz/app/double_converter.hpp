#ifndef DOUBLE_CONVERTER_HPP
#define DOUBLE_CONVERTER_HPP

void double_converter(double* a, int size);

#endif