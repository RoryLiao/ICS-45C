#ifndef INPUT_CONVERTER_HPP
#define INPUT_CONVERTER_HPP

void input_converter(int* a, int size);

#endif