#ifndef DISTANCE_HPP
#define DISTANCE_HPP

double ddistance(double lat1, double lon1, double lat2, double lon2);

#endif
