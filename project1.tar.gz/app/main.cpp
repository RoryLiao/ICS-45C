#include <iostream>
#include "distance.hpp"
#include "converter.hpp"
#include <sstream>
int main()
{       
    std::string lat1;
    std::string lon1;
    std::string city1;

    getline(std::cin, lat1, ' ');
    getline(std::cin, lon1, ' ');
    getline(std::cin, city1);
  

    std::string starting_location = lat1 + ' ' + lon1 + " (" + city1 + ")";
    
	unsigned int number_locations;
    std::string target_locations;
    
    //std::cout << "Number of locations: " << std::endl;
    std::cin >> number_locations;

    std::string closest_location;
    double closest = 0;
    std::string farthest_location;
    double farthest = 0;
    for (unsigned int i=0; i < number_locations; i++)
    {
        std::string lat2;
        std::string lon2;
        std::string city2;
        
        //std::cout << "Enter a location: " << std::endl;
        std::cin >> lat2;
        std::cin.ignore(256, ' ');
        std::cin >> lon2;
        std::cin.ignore(256, ' ');
        getline(std::cin, city2);
        double k = ddistance(converter(lat1), converter(lon1), converter(lat2), converter(lon2));
        if (closest == 0 && farthest == 0)
        {    
            closest = k;
            farthest = k;
            std::ostringstream s;
            s << k;
            closest_location = lat2 + ' ' + lon2 + " (" + city2 + ") (" + s.str() + " miles)";
            farthest_location = lat2 + ' ' + lon2 + " (" + city2 + ") (" + s.str() + " miles)";
        }
        else
        {
            if ( k < closest)
            {
                closest = k;
                std::ostringstream s;
                s << k;
                closest_location = lat2 + ' ' + lon2 + " (" + city2 + ") (" + s.str() + " miles)";
            }
            if (k > farthest)
            {
                farthest = k;
                std::ostringstream s;
                s << k;
                farthest_location = lat2 + ' ' + lon2 + " (" + city2 + ") (" + s.str() + " miles)";
            }
        }
    }
    std::cout << "Start Location: "<< starting_location  <<std::endl;
    std::cout << "Closest Location: " << closest_location << std::endl;
    std::cout << "Farthest Location: " << farthest_location << std::endl;
	return 0;
}
