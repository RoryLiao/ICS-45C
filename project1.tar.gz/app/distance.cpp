#include <cmath>
#include <string>
#include "distance.hpp"

double ddistance(double lat1, double lon1, double lat2, double lon2)
{   
    double PI = 4*atan(1);
    double rlat1 = lat1 * (PI/180);
    double rlon1 = lon1 * (PI/180);
    double rlat2 = lat2 * (PI/180);
    double rlon2 = lon2 * (PI/180);

    double dlat = rlat1 - rlat2;
    double dlon = rlon1 - rlon2;
    
    double R = 3959.9;

    double a = pow(sin(dlat/2),2) + cos(rlat1) * cos(rlat2) * pow(sin(dlon/2),2);
    double b = 2 * atan2(sqrt(a), sqrt(1-a));
    return (b * R);
}
    
