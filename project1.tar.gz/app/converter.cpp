#include <string>
#include "converter.hpp"

double converter(std::string n)
{  
    double x;
    if (n.find("S") != std::string::npos || n.find("W") != std::string::npos)
        {
	    
            x = std::stod (n);
            x *= -1;
            return x;
        }
    else
    {

      x = std::stod(n);
      return x;
    }
}
    	