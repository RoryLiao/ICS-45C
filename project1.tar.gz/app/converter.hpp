#ifndef CONVERTER_HPP
#define CONVERTER_HPP

double converter(std::string n);

#endif
